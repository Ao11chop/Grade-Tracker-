using GradeTracker1.Services;
using GradeTracker1.Components;

namespace GradeTracker1
{
    /// <summary>
    /// The entry point for the GradeTracker1 application.
    /// Responsible for configuring services and the HTTP request pipeline.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Main method that initializes and runs the web application.
        /// </summary>
        /// <param name="args">Command-line arguments passed to the application.</param>
        public static void Main(string[] args)
        {
            // --------------------------------------------------------------
            // APPLICATION BUILDER
            // --------------------------------------------------------------

            /// <summary>
            /// Creates the WebApplicationBuilder, which configures services,
            /// logging, configuration sources, and hosting settings.
            /// </summary>
            var builder = WebApplication.CreateBuilder(args);


            // --------------------------------------------------------------
            // REGISTER SERVICES
            // --------------------------------------------------------------

            /// <summary>
            /// Adds Razor Pages support used for UI rendering.
            /// </summary>
            builder.Services.AddRazorPages();

            /// <summary>
            /// Adds server-side Blazor support for interactive UI components.
            /// </summary>
            builder.Services.AddServerSideBlazor();

            /// <summary>
            /// Registers the GradeBookService as a Singleton, meaning
            /// one shared instance exists for the entire application.
            /// </summary>
            builder.Services.AddSingleton<GradeBookService>();

            /// <summary>
            /// Adds Razor component support and enables interactive server rendering.
            /// </summary>
            builder.Services.AddRazorComponents()
                .AddInteractiveServerComponents();


            // --------------------------------------------------------------
            // BUILD APPLICATION
            // --------------------------------------------------------------

            var app = builder.Build();


            // --------------------------------------------------------------
            // CONFIGURE MIDDLEWARE PIPELINE
            // --------------------------------------------------------------

            /// <summary>
            /// Checks whether the app is running in Development.
            /// If not, configures exception handling and HSTS for production.
            /// </summary>
            if (!app.Environment.IsDevelopment())
            {
                /// <summary>
                /// Redirects unhandled exceptions to /Error page.
                /// </summary>
                app.UseExceptionHandler("/Error");

                /// <summary>
                /// Enables HTTP Strict Transport Security (HSTS)
                /// to enforce secure HTTPS communication.
                /// </summary>
                app.UseHsts();
            }

            /// <summary>
            /// Forces all HTTP traffic to redirect to HTTPS.
            /// </summary>
            app.UseHttpsRedirection();

            /// <summary>
            /// Enables serving static files from wwwroot (CSS, JS, images).
            /// </summary>
            app.UseStaticFiles();

            /// <summary>
            /// Enables antiforgery validation for form submissions.
            /// </summary>
            app.UseAntiforgery();


            // --------------------------------------------------------------
            // MAP RAZOR COMPONENTS
            // --------------------------------------------------------------

            /// <summary>
            /// Maps the root Razor Component and enables interactive server rendering.
            /// </summary>
            app.MapRazorComponents<App>()
                .AddInteractiveServerRenderMode();


            // --------------------------------------------------------------
            // RUN APPLICATION
            // --------------------------------------------------------------

            /// <summary>
            /// Executes the web application and begins listening for requests.
            /// </summary>
            app.Run();
        }
    }
}
