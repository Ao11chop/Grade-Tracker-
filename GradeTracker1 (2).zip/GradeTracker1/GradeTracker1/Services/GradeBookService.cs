﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using GradeTracker1.Models;

namespace GradeTracker1.Services
{
    /// <summary>
    /// Service that holds the main grade data and handles file operations, such as loading and saving student grades.
    /// </summary>
    public class GradeBookService
    {
        /// <summary>
        /// Stores all students with their associated courses and assignments.
        /// The key is the student's name.
        /// </summary>
        public Dictionary<string, Student> Students { get; private set; } = new();

        /// <summary>
        /// The file path where the grade data is saved.
        /// </summary>
        private readonly string _filePath;

        /// <summary>
        /// Initializes a new instance of the <see cref="GradeBookService"/> class.
        /// Creates a "Data" directory and sets the file path for storing grade data.
        /// </summary>
        public GradeBookService()
        {
            // Create a Data folder next to the app and store grades.json there
            var dataFolder = Path.Combine(AppContext.BaseDirectory, "Data");
            Directory.CreateDirectory(dataFolder);
            _filePath = Path.Combine(dataFolder, "grades.json");
        }

        /// <summary>
        /// Asynchronously loads grade data from the file into memory.
        /// </summary>
        /// <returns>A task that represents the asynchronous load operation.</returns>
        /// <remarks>
        /// If the file exists, it will deserialize the JSON data into a dictionary of students.
        /// </remarks>
        public async Task LoadAsync()
        {
            try
            {
                if (File.Exists(_filePath))
                {
                    string json = await File.ReadAllTextAsync(_filePath);

                    // Deserialize JSON into dictionary
                    var data = JsonSerializer.Deserialize<Dictionary<string, Student>>(json);

                    if (data != null)
                    {
                        Students = data;
                    }
                }
            }
            catch (Exception ex)
            {
                // Basic exception handling for reading the file
                Console.WriteLine($"Error loading file: {ex.Message}");
            }
        }

        /// <summary>
        /// Asynchronously saves the current grade data to the file.
        /// </summary>
        /// <returns>A task that represents the asynchronous save operation.</returns>
        /// <remarks>
        /// Serializes the current student data to JSON format and writes it to the grades.json file.
        /// </remarks>
        public async Task SaveAsync()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };

                // Convert dictionary to JSON
                string json = JsonSerializer.Serialize(Students, options);

                await File.WriteAllTextAsync(_filePath, json);
            }
            catch (Exception ex)
            {
                // Exception handling for saving the data
                Console.WriteLine($"Error saving file: {ex.Message}");
            }
        }

        /// <summary>
        /// Adds a new student to the gradebook if the name is valid and doesn't already exist.
        /// </summary>
        /// <param name="name">The name of the student to add.</param>
        /// <remarks>
        /// This method ensures that a student with the same name does not already exist
        /// and that the name is not empty or whitespace.
        /// </remarks>
        public void AddStudent(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return;

            name = name.Trim();

            // Avoid duplicates
            if (!Students.ContainsKey(name))
            {
                Students[name] = new Student { Name = name };
            }
        }

        /// <summary>
        /// Adds a course to the selected student if the course doesn't already exist.
        /// </summary>
        /// <param name="studentName">The name of the student to add the course to.</param>
        /// <param name="courseName">The name of the course to add.</param>
        /// <remarks>
        /// This method ensures that the course is added only if it doesn't already exist
        /// for the student.
        /// </remarks>
        public void AddCourse(string studentName, string courseName)
        {
            if (!Students.TryGetValue(studentName, out var student)) return;
            if (string.IsNullOrWhiteSpace(courseName)) return;

            courseName = courseName.Trim();

            if (!student.Courses.ContainsKey(courseName))
            {
                student.Courses[courseName] = new Course { Name = courseName };
            }
        }

        /// <summary>
        /// Adds an assignment to a specific course for a student.
        /// </summary>
        /// <param name="studentName">The name of the student to add the assignment to.</param>
        /// <param name="courseName">The name of the course to add the assignm
