﻿using System.Collections.Generic;

namespace GradeTracker1.Models
{
    // Represents a single student in the grade tracker
    public class Student
    {
        // Unique ID for the student
        public string Id { get; set; } = Guid.NewGuid().ToString();

        // Student's displayed name
        public string Name { get; set; } = string.Empty;

        // Stores the student's courses (key = course name)
        public Dictionary<string, Course> Courses { get; set; } = new();

        // Calculates the overall average across all courses
        public double GetOverallAverage()
        {
            if (Courses.Count == 0) return 0;

            double total = 0;

            // Loop through each course and add its average
            foreach (var course in Courses.Values)
            {
                total += course.GetCourseAverage();
            }

            // Return average of all courses
            return total / Courses.Count;
        }
    }
}
