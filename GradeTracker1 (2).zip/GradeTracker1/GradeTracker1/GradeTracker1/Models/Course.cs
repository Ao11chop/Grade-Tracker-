﻿using System.Collections.Generic;

namespace GradeTracker1.Models
{
    // Represents a single course (ex: Math, English)
    public class Course
    {
        // Course name
        public string Name { get; set; } = string.Empty;

        // Assignments for the course (key = assignment name)
        public Dictionary<string, Assignment> Assignments { get; set; } = new();

        // Calculates the weighted average of all assignments
        public double GetCourseAverage()
        {
            if (Assignments.Count == 0) return 0;

            double total = 0;
            double weightTotal = 0;

            // Loop through assignments and add weighted scores
            foreach (var assignment in Assignments.Values)
            {
                total += assignment.Score * assignment.Weight;
                weightTotal += assignment.Weight;
            }

            if (weightTotal == 0) return 0;

            // Return weighted average
            return total / weightTotal;
        }
    }
}
