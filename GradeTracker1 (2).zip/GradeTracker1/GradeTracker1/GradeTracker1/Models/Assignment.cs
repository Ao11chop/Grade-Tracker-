﻿namespace GradeTracker1.Models
{
    // Represents a single assignment inside a course
    public class Assignment
    {
        // Assignment title
        public string Name { get; set; } = string.Empty;

        // Score the student earned (0–100)
        public double Score { get; set; }

        // How much the assignment counts (default = 1)
        public double Weight { get; set; } = 1;
    }
}
