﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using GradeTracker1.Models;

namespace GradeTracker1.Services
{
    // Service that holds the main grade data and handles file operations
    public class GradeBookService
    {
        // Stores all students (key = student name)
        public Dictionary<string, Student> Students { get; private set; } = new();

        // File where the grade data is saved
        private readonly string _filePath;

        public GradeBookService()
        {
            // Create a Data folder next to the app and store grades.json there
            var dataFolder = Path.Combine(AppContext.BaseDirectory, "Data");
            Directory.CreateDirectory(dataFolder);
            _filePath = Path.Combine(dataFolder, "grades.json");
        }

        // Loads data from the file into memory
        public async Task LoadAsync()
        {
            try
            {
                if (File.Exists(_filePath))
                {
                    string json = await File.ReadAllTextAsync(_filePath);

                    // Deserialize JSON into dictionary
                    var data = JsonSerializer.Deserialize<Dictionary<string, Student>>(json);

                    if (data != null)
                    {
                        Students = data;
                    }
                }
            }
            catch (Exception ex)
            {
                // Basic exception handling for reading the file
                Console.WriteLine($"Error loading file: {ex.Message}");
            }
        }

        // Saves the current data to the file
        public async Task SaveAsync()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };

                // Convert dictionary to JSON
                string json = JsonSerializer.Serialize(Students, options);

                await File.WriteAllTextAsync(_filePath, json);
            }
            catch (Exception ex)
            {
                // Exception handling for saving the data
                Console.WriteLine($"Error saving file: {ex.Message}");
            }
        }

        // Adds a new student if the name is valid
        public void AddStudent(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return;

            name = name.Trim();

            // Avoid duplicates
            if (!Students.ContainsKey(name))
            {
                Students[name] = new Student { Name = name };
            }
        }

        // Adds a course to the selected student
        public void AddCourse(string studentName, string courseName)
        {
            if (!Students.TryGetValue(studentName, out var student)) return;
            if (string.IsNullOrWhiteSpace(courseName)) return;

            courseName = courseName.Trim();

            if (!student.Courses.ContainsKey(courseName))
            {
                student.Courses[courseName] = new Course { Name = courseName };
            }
        }

        // Adds an assignment to a specific course
        public void AddAssignment(string studentName, string courseName,
                                  string assignmentName, double score, double weight)
        {
            // Try to find the student & course
            if (!Students.TryGetValue(studentName, out var student)) return;
            if (!student.Courses.TryGetValue(courseName, out var course)) return;

            if (string.IsNullOrWhiteSpace(assignmentName)) return;

            // Add or update assignment
            course.Assignments[assignmentName.Trim()] = new Assignment
            {
                Name = assignmentName.Trim(),
                Score = score,
                Weight = weight
            };
        }
    }
}
