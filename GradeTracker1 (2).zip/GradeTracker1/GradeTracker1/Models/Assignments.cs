﻿namespace GradeTracker1.Models
{
    /// <summary>
    /// Represents a single assignment within a course,
    /// including its title, earned score, and weighting.
    /// </summary>
    public class Assignment
    {
        /// <summary>
        /// Gets or sets the assignment title.
        /// </summary>
        /// <remarks>
        /// Used to identify the assignment (e.g., "Homework 1", "Midterm Exam").
        /// </remarks>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the score earned by the student.
        /// Value should typically be between 0 and 100.
        /// </summary>
        public double Score { get; set; }

        /// <summary>
        /// Gets or sets how much the assignment counts toward the course grade.
        /// </summary>
        /// <remarks>
        /// A default value of 1 means all assignments are weighted equally unless specified otherwise.
        /// </remarks>
        public double Weight { get; set; } = 1;
    }
}
