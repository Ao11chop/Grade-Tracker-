﻿using System.Collections.Generic;

namespace GradeTracker1.Models
{
    /// <summary>
    /// Represents a single course (e.g., Math, English), 
    /// including the course name and its associated assignments.
    /// </summary>
    public class Course
    {
        /// <summary>
        /// Gets or sets the name of the course (e.g., "Math", "English").
        /// </summary>
        /// <remarks>
        /// This property is used to store the course's title for identification.
        /// </remarks>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets a dictionary of assignments for the course.
        /// The key is the assignment name, and the value is the corresponding <see cref="Assignment"/>.
        /// </summary>
        /// <remarks>
        /// This dictionary stores all the assignments for the course, with their names as keys.
        /// </remarks>
        public Dictionary<string, Assignment> Assignments { get; set; } = new();

        /// <summary>
        /// Calculates the weighted average of all assignments in the course.
        /// </summary>
        /// <returns>
        /// A <see cref="double"/> representing the weighted average of all assignments.
        /// Returns 0 if there are no assignments or if all weights are zero.
        /// </returns>
        /// <remarks>
        /// This method loops through the assignments, calculates the weighted score,
        /// and returns the weighted average.
        /// </remarks>
        public double GetCourseAverage()
        {
            if (Assignments.Count == 0) return 0;

            double total = 0;
            double weightTotal = 0;

            // Loop through assignments and add weighted scores
            foreach (var assignment in Assignments.Values)
            {
                total += assignment.Score * assignment.Weight;
                weightTotal += assignment.Weight;
            }

            if (weightTotal == 0) return 0;

            // Return weighted average
            return total / weightTotal;
        }
    }
}
