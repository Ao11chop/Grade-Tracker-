﻿using System.Collections.Generic;

namespace GradeTracker1.Models
{
    /// <summary>
    /// Represents a single student in the grade tracker,
    /// including their ID, name, and associated courses.
    /// </summary>
    public class Student
    {
        /// <summary>
        /// Gets or sets the unique ID for the student.
        /// </summary>
        /// <remarks>
        /// The ID is generated automatically using a new GUID.
        /// </remarks>
        public string Id { get; set; } = Guid.NewGuid().ToString();

        /// <summary>
        /// Gets or sets the student's displayed name.
        /// </summary>
        /// <remarks>
        /// This property stores the student's name, which is shown to the user.
        /// </remarks>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets a dictionary of courses the student is enrolled in.
        /// The key is the course name, and the value is the corresponding <see cref="Course"/>.
        /// </summary>
        /// <remarks>
        /// This dictionary allows storing multiple courses per student, 
        /// with each course being accessible by its name.
        /// </remarks>
        public Dictionary<string, Course> Courses { get; set; } = new();

        /// <summary>
        /// Calculates the overall average across all courses for the student.
        /// </summary>
        /// <returns>
        /// A <see cref="double"/> representing the student's overall average across all courses.
        /// Returns 0 if there are no courses.
        /// </returns>
        /// <remarks>
        /// This method calculates the average of each course's weighted average and returns
        /// the mean average of all courses that the student is enrolled in.
        /// </remarks>
        public double GetOverallAverage()
        {
            if (Courses.Count == 0) return 0;

            double total = 0;

            // Loop through each course and add its average
            foreach (var course in Courses.Values)
            {
                total += course.GetCourseAverage();
            }

            // Return average of all courses
            return total / Courses.Count;
        }
    }
}
